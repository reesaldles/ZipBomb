I am not responsible for any legal repercussions. Use with consent.

___________________________________________________________________

To use the zip bomb, copy and paste the "(Insert Name Here)" folder.